<?php
return array(
	//'配置项'=>'配置值'
		'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    //  'DB_NAME'               =>  'chensiweimy',          // 数据库名
    // 'DB_USER'               =>  'chensiweimy',      // 用户名
    // 'DB_PWD'                =>  '732C669',          // 密码


     'DB_NAME'               =>  'zuqiuweb',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  'root',          // 密码



    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'news_',    // 数据库表前缀
    'LAYOUT_ON'             =>  true, // 是否启用布局
    'LAYOUT_NAME'           =>  'layout', // 当前布局名称 默认为layout
    'TMPL_TEMPLATE_SUFFIX'  =>  '.php',     // 默认模板文件后缀

);