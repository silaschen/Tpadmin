<?php 
namespace Home\Controller;
use Think\Controller;
/**
* 
*/
class PicnewsController extends Controller
{
	
	public function view()
	{
		$id=$_GET['id'];
		$picnews=M("picnews")->where("id=$id")->find();
		$this->assign("picnews",$picnews);
		M("picnews")->where("id=$id")->setInc("view");
		$this->display();

	}
}










 ?>