 <li class="media" comment_id="{$value['id']}">
                  <div class="media-left">
                      <a href="#" rel="author"><img width="48" height="48" class="media-object" src="__PUBLIC__/img/1.jpg" alt="xiaoshenzhen"></a></div>
                  <div class="media-body">
                      <div class="media-heading">
                          <a href="/user/35157" rel="author">{$value.editor}</a> 评论于 {$value.time}  
                      </div>
                      <div class="media-content">
                          <p>{$value.content}</p>
                      
                            



                      </div>
                  </div>
                  <div class="media-action">
                      <a  href="javascript:void(0);"  rid="{$value.id}"><i class="icon-reply"></i> 回复</a>
                  </div>
        </li><hr>