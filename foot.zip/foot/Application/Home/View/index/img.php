<?php 
 ?>
 <div class="row">
 	


 </div><div class="col-md-5" style="padding:150px 20px;">
 		<form enctype="multipart/form-data" action="__APP__/home/index/upload" method="post">
 				<div class="form-group">
 					<label>更换头像</label>

 					<input type="file" name="head" class="form-control">
 				</div>
 				<div class="form-group">
 					<button class="btn btn-success">提交</a>
 				</div>

 		</form>



 </div>
