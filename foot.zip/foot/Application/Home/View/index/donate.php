<ul class="breadcrumb"><li><a href="">Home</a></li>
<li class="active">捐献</li>
</ul>
  <div class="col-md-8">
      <h2>捐赠</h2><hr>
      <p class="text-info">我就是站长，喜欢吃牛舌饼。写这个网站纯属自己的一时冲动，因为我知道自学php所遇到的问题，和困难。为了帮助大家，我独资创建了本网站。本站旨在帮助每一位热爱php开发的同学。
      本站主要以thinphp,yii框架为核心进行知识讲解。所有内容免费开源。但是大家都知道，服务器和七牛云需要支付一定费用。恳请各位同学捐赠自己的一份心意。你的支持将是我们更大的动力！无论捐多捐少，你的心意将是陈某某巨大的动力。当然，我也希望志同道合的朋友加入我，一同开创天地。</p>	
    <div class="col-md-4">
    <h3>支付宝扫一扫</h3>
    <img src="img/pay.jpg" class="img-responsive"></div>
    
</div>