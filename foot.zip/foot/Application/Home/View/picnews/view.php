<ul class="breadcrumb"><li><a href="__APP__">Home</a></li>
<li class="active"><a href="#">媒体新闻</a></li>
<li class="active">{$picnews.title}</li>
</ul>
<div class="row">
<div class="col-lg-8">
	<h2><?php echo $picnews['title']?></h2>
      <p><span class="glyphicon glyphicon-user"></span><?php echo $picnews['editor']?> &nbsp <span class="glyphicon glyphicon-time"></span><?php echo $picnews['addtime']?> &nbsp  <span class="glyphicon glyphicon-eye-open"></span><?php echo $picnews['view']?>&nbsp &nbsp<span class="glyphicon glyphicon-comment"></span><?php $where['lesson_id']=$picnews['id']; $count=M("comment")->where($where)->count(); echo $count?></p>	  
      <hr>
      <p class="text-info"><?php echo $picnews['content']?></p>
      <hr>
     <?php if(session("?name")){



      ?>
     <form>
    <div class="form-group">
        <textarea name="comment" type="text" class="form-control" id="comm" rows="3" placeholder="pls login here to write ur comment"></textarea>
    </div>
    <div class="form-group">
    	  <a class="comment-submit btn btn-info"  leid="{$picnews['id']}" pid="0" action="__APP__/home/lesson/addcomment">评论</a>
    </div>
    </form>
    <?php }else{?>
    <p>请登录后评论<a class="btn" href="__APP__/home/user/login">登录</a></p>
    <?php }?>
    </div>
    </div>
    <script type="text/javascript" src="__PUBLIC__/js/comm.js"></script>
