<?php 
namespace Home\Model;
use Think\Model;
/**
* 
*/
class LessonModel extends Model
{
	
	
}

 ?>