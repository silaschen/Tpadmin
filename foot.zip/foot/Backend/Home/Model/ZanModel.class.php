<?php 
namespace Home\Model;
use Think\Model;
/**
* 
*/
class ZanModel extends Model
{
	
	
}


 ?>